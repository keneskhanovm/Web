import json
from django.shortcuts import render
from api.models import Company, Vacancy
from django.http.response import HttpResponse, JsonResponse
from django.http.request import HttpRequest
from api.serializers import CompanySerializer
from django.views.decorators.csrf import csrf_exempt
from django.views import View
from api.serializers import CompanySerializer, CompanySerializer2, VacancySerializer
from rest_framework.decorators import api_view
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework import status
from rest_framework.views import APIView


class CompanyListAPIView(APIView):
    def get(self, request):
        c = Company.objects.all()
        serializer = CompanySerializer2(c, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = CompanySerializer2(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return JsonResponse(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class CompanyDetailAPIView(APIView):
    def get_object(self, id):
        try:
            return Company.objects.get(id=id)
        except Company.DoesNotExist as e:
            return HttpResponse("<h1>No such company.</h1>")

    def get(self, request, id):
        c_id = self.get_object(id)
        serializer = CompanySerializer2(c_id)
        return Response(serializer.data)

    def put(self, request, id):
        c_id = self.get_object(id)
        serializer = CompanySerializer(instance=c_id, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors)

    def delete(self, request, id):
        c_id = self.get_object(id)
        c_id.delete()
        return Response({'deleted': True})



@api_view(['GET', 'POST'])
def get_companies(request):
    if request.method == 'GET':
        c = Company.objects.all()
        serializer = CompanySerializer2(c, many=True)
        return Response(serializer.data)
    elif request.method == 'POST':
        # request_body = json.loads(request.body)
        serializer = CompanySerializer2(data=request.data)
        # company= Company()
        # company.name =data.get('name','')
        # company.save()
        # return JsonResponse(company.to_json())
        if serializer.is_valid():
            serializer.save()
            return JsonResponse(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    return JsonResponse({'error': 'bad request'})


@api_view(['GET', 'PUT', 'DELETE'])
def get_company(request, id):
    try:
        c_id = Company.objects.get(id=id)
    except Company.DoesNotExist as e:
        return HttpResponse("<h1>No such company.</h1>")

    if request.method == 'GET':
        serializer = CompanySerializer(c_id)
        return Response(serializer.data)

    elif request.method == 'PUT':
        # request_body = json.loads(request.body)
        serializer = CompanySerializer(instance=c_id, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors)

    elif request.method == 'DELETE':
        c_id.delete()
        return Response({'deleted': True})
    return JsonResponse({'error': 'bad request'})


def get_vacancy_by_company(request, id):
    try:
        company = Company.objects.get(id=id)
    except Company.DoesNotExist as e:
        return JsonResponse({'error': str(e)})

    vacancies = company.vacancies.all()
    serializer = VacancySerializer(vacancies, many=True)
    return JsonResponse(serializer.data, safe=False)


@csrf_exempt
def get_vacancies(request):
    if request.method == 'GET':
        vacancies = Vacancy.objects.all()
        vacancies_json = [v.to_json() for v in vacancies]
        return JsonResponse(vacancies_json, safe=False)
    elif request.method == 'POST':
        pass


def get_vacancy(request, id):
    try:
        vacancy = Vacancy.objects.get(id=id)
    except Vacancy.DoesNotExist as e:
        return JsonResponse({'error': str(e)})
    return JsonResponse(vacancy.to_json())


# def sort_salary(vac):
#    v = vac.objects.order_by('-salary')
#    return v


def top_ten(request):
    # v = Vacancy.objects.all()
    v = Vacancy.objects.order_by('-salary')
    # out = sorted(v, key=sort_salary)[-10:]
    v = [cm.to_json() for cm in v]
    return JsonResponse(v, safe=False)
