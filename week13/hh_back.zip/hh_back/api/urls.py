from django.urls import path
from api.views.views import get_companies, get_company, get_vacancy_by_company, get_vacancies, get_vacancy, top_ten
from api.views.views_generic import CompanyListAPIView, CompanyDetailAPIView, VacancyDetailAPIView, VacancyListAPIView
from rest_framework_jwt.views import obtain_jwt_token

urlpatterns = [
    path('login/', obtain_jwt_token),
    path("companies", CompanyListAPIView.as_view()),
    path("companies/<int:id>/", CompanyDetailAPIView.as_view()),
    path('companies/<int:id>/vacancies', get_vacancy_by_company),
    path("vacancies/", VacancyListAPIView.as_view()),
    path("vacancies/<int:id>/", VacancyDetailAPIView.as_view()),
    path("vacancies/top_ten/", top_ten),
]
