from django.contrib import admin

from api.models import Company, Vacancy

admin.site.register(Company)
admin.site.register(Vacancy)


class CompanyAdmin(admin.ModelAdmin):
    list_display = ('id', 'name')
# Register your models here.
