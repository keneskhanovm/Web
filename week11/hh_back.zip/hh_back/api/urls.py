from django.urls import path
from api.views import get_companies, get_company, get_vacancy_by_company, get_vacancies, get_vacancy, top_ten

urlpatterns = [
    path("companies", get_companies),
    path("companies/<int:id>/", get_company),
    path('companies/<int:id>/vacancies', get_vacancy_by_company),
    path("vacancies/", get_vacancies),
    path("vacancies/<int:id>/", get_vacancy),
    path("vacancies/top_ten/", top_ten),
]
